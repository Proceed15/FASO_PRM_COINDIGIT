public class AuthResponseDTO
{
    public string Token { get; set; }
}